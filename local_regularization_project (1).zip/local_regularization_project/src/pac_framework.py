"""
pac_framework.py

PAC learning evaluation framework for running controlled experiments
on the hypothesis class H△ with different learners.

Implements the experimental protocol from the paper's arguments:
- Fix a triple (A, B, C) and true hypothesis h*
- Create the uniform distribution D over {(x, A) : x ∈ A}
- Draw training samples of varying size
- Evaluate test error on fresh samples from D
"""

import numpy as np
from typing import Dict, List, Tuple, Callable
from .hypothesis_class import (
    Hypothesis,
    HypothesisClassHTriangle,
    generate_valid_triple,
    generate_hypotheses_for_triple,
    create_realizable_distribution,
    sample_from_distribution,
    STAR,
)


def run_single_trial(
    learner,
    dist: Dict,
    n_train: int,
    n_test: int,
    rng: np.random.Generator,
) -> float:
    """
    Run a single PAC learning trial.

    Args:
        learner: A learner object with .evaluate(X_train, Y_train, X_test, Y_test)
        dist: Realizable distribution
        n_train: Training sample size
        n_test: Number of test points
        rng: Random number generator

    Returns:
        Test error (float between 0 and 1)
    """
    X_train, Y_train = sample_from_distribution(dist, n_train, rng)
    X_test, Y_test = sample_from_distribution(dist, n_test, rng)

    error = learner.evaluate(X_train, Y_train, X_test, Y_test)
    return error


def run_experiment(
    learner,
    dist: Dict,
    sample_sizes: List[int],
    n_test: int = 100,
    n_trials: int = 30,
    seed: int = 42,
) -> Dict[int, List[float]]:
    """
    Run a PAC learning experiment across multiple sample sizes.

    For each sample size, runs multiple trials and records the test error.

    Args:
        learner: Learner object
        dist: Realizable distribution
        sample_sizes: List of training set sizes to evaluate
        n_test: Number of test points per trial
        n_trials: Number of independent trials per sample size
        seed: Random seed

    Returns:
        Dictionary mapping sample_size → list of test errors
    """
    rng = np.random.default_rng(seed)
    results = {}

    for n in sample_sizes:
        errors = []
        for trial in range(n_trials):
            trial_rng = np.random.default_rng(seed + trial * 1000 + n)
            err = run_single_trial(learner, dist, n, n_test, trial_rng)
            errors.append(err)
        results[n] = errors
        mean_err = np.mean(errors)
        print(f"  n={n:4d}: mean error = {mean_err:.4f} ± {np.std(errors):.4f}")

    return results


def setup_erm_failure_experiment(
    domain_size: int = 200,
    k: int = 20,
    num_triples: int = 100,
    seed: int = 42,
) -> Tuple[HypothesisClassHTriangle, Dict, Hypothesis]:
    """
    Set up the ERM failure experiment from the paper.

    Creates:
    1. An H△ with controlled parameters
    2. Picks a specific triple (A, B, C)
    3. Creates the uniform distribution over {(x, A) : x ∈ A}
    4. The true hypothesis labels everything in A with set A

    Returns:
        (hypothesis_class, distribution, true_hypothesis)
    """
    rng = np.random.default_rng(seed)

    H_triangle = HypothesisClassHTriangle(
        domain_size=domain_size, k=k, num_triples=num_triples, seed=seed
    )

    # Pick the first triple and use the hypothesis that labels A∩B→A, A∩C→A, B∩C→B
    # (This is the "true" hypothesis where A is the dominant set)
    A, B, C = H_triangle.triples[0]
    true_h = Hypothesis(A, B, C, ab_label="A", ac_label="A", bc_label="B")

    dist = create_realizable_distribution(A, true_h)

    return H_triangle, dist, true_h


def compute_theoretical_erm_error_bound(k: int, n: int) -> float:
    """
    Compute the theoretical lower bound on ERM error for H△.

    When the distribution is uniform over A with |A| = k,
    and the training set has n < k/2 points, the probability
    that a test point is unseen is approximately (k - n) / k.

    On unseen points, ERM has a nonzero probability of predicting
    the wrong label, leading to constant error.
    """
    if n >= k:
        # Once n covers most of A, error should be small
        # (coupon collector: need ~k*ln(k) to see all)
        unseen_fraction = max(0, 1 - n / k)
        return unseen_fraction * 0.5  # rough bound
    else:
        unseen_fraction = (k - n) / k
        return unseen_fraction * 0.5  # ERM picks wrong with ~50% prob on unseen


def compute_correct_learner_error_bound(k: int, n: int) -> float:
    """
    Compute the theoretical error bound for the Default-Star learner.

    The learner errs only on points whose region (A∩B, A∩C, or B∩C)
    has not been observed. Each region has size k/2. The error decreases
    as more regions are covered by the sample.

    Probability that a specific region of size k/2 has no sample points:
    P(miss region) ≈ ((k - k/2) / k)^n = (1/2)^n for uniform over A.

    But actually the distribution is uniform over A, and each region
    A∩B, A∩C only covers half of A, so the coverage depends on the
    true hypothesis.
    """
    # Simplified: error proportional to fraction of unseen unique points
    if n == 0:
        return 1.0
    # Expected fraction of A not covered after n uniform draws
    unseen = (1 - 1.0 / k) ** n
    return unseen
