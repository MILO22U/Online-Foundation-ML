"""
hypothesis_class.py

Implements the candidate counterexample hypothesis class H△ from Asilis et al. (COLT 2024).

The class H△ is defined over:
  - Domain X = {0, 1, ..., N-1}  (finite approximation of ℕ)
  - Labels Y = {"*"} ∪ 2^X       (star label plus subsets of X)

For each valid triple (A, B, C) of subsets of X satisfying:
  1. |A| = |B| = |C| = k
  2. |A ∩ B| = |A ∩ C| = |B ∩ C| = k/2
  3. A ∩ B ∩ C = ∅

We define 8 hypotheses — one for each assignment of labels on the three
pairwise intersection regions (A∩B, A∩C, B∩C), where each region
independently picks one of the two overlapping sets as its constant label.
"""

import numpy as np
from itertools import product
from typing import List, Tuple, Dict, FrozenSet, Optional


# Sentinel for the "star" label
STAR = "*"


class Hypothesis:
    """
    A hypothesis h in H△.

    h(x) = '*' for x not in A ∪ B ∪ C
    h is constant on each of A∩B, A∩C, B∩C, choosing one of two possible labels.
    """

    def __init__(
        self,
        A: FrozenSet[int],
        B: FrozenSet[int],
        C: FrozenSet[int],
        ab_label: str,  # label for region A∩B: either 'A' or 'B'
        ac_label: str,  # label for region A∩C: either 'A' or 'C'
        bc_label: str,  # label for region B∩C: either 'B' or 'C'
    ):
        self.A = A
        self.B = B
        self.C = C
        self.ab_label = ab_label
        self.ac_label = ac_label
        self.bc_label = bc_label

        # Precompute regions
        self.A_inter_B = A & B
        self.A_inter_C = A & C
        self.B_inter_C = B & C
        self.union_ABC = A | B | C

        # Map label names to actual frozensets for output
        self._label_map = {"A": A, "B": B, "C": C}

    def predict(self, x: int) -> object:
        """Predict the label for a single point x."""
        if x not in self.union_ABC:
            return STAR
        if x in self.A_inter_B:
            return self._label_map[self.ab_label]
        if x in self.A_inter_C:
            return self._label_map[self.ac_label]
        if x in self.B_inter_C:
            return self._label_map[self.bc_label]
        # Should not reach here for valid triples (A∩B∩C = ∅ and union covers)
        return STAR

    def predict_batch(self, xs: np.ndarray) -> list:
        """Predict labels for a batch of points."""
        return [self.predict(int(x)) for x in xs]

    def empirical_error(self, X: np.ndarray, Y: list) -> float:
        """Compute empirical 0-1 loss on a labeled sample."""
        predictions = self.predict_batch(X)
        errors = sum(1 for pred, true in zip(predictions, Y) if pred != true)
        return errors / len(X) if len(X) > 0 else 0.0

    def __repr__(self):
        return (
            f"Hypothesis(|A|={len(self.A)}, |B|={len(self.B)}, |C|={len(self.C)}, "
            f"AB→{self.ab_label}, AC→{self.ac_label}, BC→{self.bc_label})"
        )


def generate_valid_triple(
    domain_size: int, k: int, rng: np.random.Generator
) -> Tuple[FrozenSet[int], FrozenSet[int], FrozenSet[int]]:
    """
    Generate a valid triple (A, B, C) from domain {0, ..., domain_size-1}.

    Requirements:
      |A| = |B| = |C| = k
      |A∩B| = |A∩C| = |B∩C| = k/2
      A ∩ B ∩ C = ∅

    Construction:
      We need 3 disjoint groups of size k/2 each (for A∩B \\ C, A∩C \\ B, B∩C \\ A).
      Total elements needed: 3 * (k/2) = 3k/2.
      Then: A = (A∩B \\ C) ∪ (A∩C \\ B), B = (A∩B \\ C) ∪ (B∩C \\ A), etc.
    """
    assert k % 2 == 0, "k must be even"
    half_k = k // 2
    needed = 3 * half_k

    assert domain_size >= needed, (
        f"Domain size {domain_size} too small for k={k} (need {needed} elements)"
    )

    # Sample 3 * (k/2) distinct elements and partition into 3 groups
    elements = rng.choice(domain_size, size=needed, replace=False)

    ab_only = frozenset(elements[:half_k].tolist())       # A∩B but not C
    ac_only = frozenset(elements[half_k:2*half_k].tolist())  # A∩C but not B
    bc_only = frozenset(elements[2*half_k:].tolist())     # B∩C but not A

    A = ab_only | ac_only
    B = ab_only | bc_only
    C = ac_only | bc_only

    # Verify properties
    assert len(A) == k and len(B) == k and len(C) == k
    assert len(A & B) == half_k
    assert len(A & C) == half_k
    assert len(B & C) == half_k
    assert len(A & B & C) == 0

    return A, B, C


def generate_hypotheses_for_triple(
    A: FrozenSet[int], B: FrozenSet[int], C: FrozenSet[int]
) -> List[Hypothesis]:
    """
    Generate all 8 hypotheses for a given valid triple (A, B, C).

    Each hypothesis picks one of {A,B} for A∩B, one of {A,C} for A∩C,
    and one of {B,C} for B∩C → 2^3 = 8 combinations.
    """
    hypotheses = []
    for ab_choice, ac_choice, bc_choice in product(
        ["A", "B"], ["A", "C"], ["B", "C"]
    ):
        h = Hypothesis(A, B, C, ab_choice, ac_choice, bc_choice)
        hypotheses.append(h)
    return hypotheses


class HypothesisClassHTriangle:
    """
    The hypothesis class H△.

    In the full theoretical setting, H△ is the union of all hypotheses
    arising from all valid triples. For computational experiments, we
    work with a finite collection of triples.
    """

    def __init__(self, domain_size: int = 100, k: int = 6, num_triples: int = 50, seed: int = 42):
        self.domain_size = domain_size
        self.k = k
        self.rng = np.random.default_rng(seed)

        self.triples: List[Tuple[FrozenSet[int], FrozenSet[int], FrozenSet[int]]] = []
        self.hypotheses: List[Hypothesis] = []

        for _ in range(num_triples):
            A, B, C = generate_valid_triple(domain_size, k, self.rng)
            self.triples.append((A, B, C))
            self.hypotheses.extend(generate_hypotheses_for_triple(A, B, C))

        print(
            f"H△ constructed: {len(self.triples)} triples, "
            f"{len(self.hypotheses)} total hypotheses, "
            f"domain size={domain_size}, k={k}"
        )

    def get_hypotheses_for_triple(self, triple_idx: int) -> List[Hypothesis]:
        """Get the 8 hypotheses for a specific triple."""
        return self.hypotheses[triple_idx * 8 : (triple_idx + 1) * 8]

    def find_zero_error_hypotheses(self, X: np.ndarray, Y: list) -> List[Hypothesis]:
        """Find all hypotheses with zero empirical error on the sample."""
        # Quick filter: only check hypotheses whose triple overlaps with sample
        sample_set = set(int(x) for x in X)
        candidates = []
        for h in self.hypotheses:
            # If any sample point is in the hypothesis's active region,
            # we need to check it; otherwise it trivially predicts '*'
            if sample_set & h.union_ABC:
                candidates.append(h)
            else:
                # h predicts * everywhere in sample — check if labels are all *
                if all(y == STAR for y in Y):
                    candidates.append(h)
        
        if not candidates:
            candidates = self.hypotheses  # fallback

        return [h for h in candidates if h.empirical_error(X, Y) == 0.0]


def create_realizable_distribution(
    A: FrozenSet[int],
    h_true: Hypothesis,
) -> Dict:
    """
    Create a realizable distribution D over X × Y.

    For the ERM failure argument, D is the uniform distribution
    over {(x, A) : x ∈ A}, i.e., every point in A has true label A.
    """
    A_list = sorted(A)
    return {
        "support_X": np.array(A_list),
        "support_Y": [A] * len(A_list),  # true label is A for all x in A
        "h_true": h_true,
        "A": A,
    }


def sample_from_distribution(
    dist: Dict, n: int, rng: np.random.Generator
) -> Tuple[np.ndarray, list]:
    """Sample n i.i.d. points from a realizable distribution."""
    indices = rng.choice(len(dist["support_X"]), size=n, replace=True)
    X = dist["support_X"][indices]
    Y = [dist["support_Y"][i] for i in indices]
    return X, Y
