"""
visualization.py

Plotting utilities for the multiclass learning experiments.
Generates publication-quality figures showing learner performance.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from typing import Dict, List, Optional, Tuple

# Use a clean style
matplotlib.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "#FAFAFA",
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "font.family": "serif",
    "font.size": 11,
    "axes.labelsize": 13,
    "axes.titlesize": 15,
    "legend.fontsize": 10,
    "figure.dpi": 150,
})

# Color palette matching the presentation
COLORS = {
    "navy": "#1A1F3D",
    "accent": "#E8913A",
    "green": "#2D8A56",
    "red": "#C0392B",
    "teal": "#1A7A6D",
    "blue": "#2B3A67",
    "purple": "#6D2E46",
}


def plot_learning_curves(
    results_dict: Dict[str, Dict[int, List[float]]],
    title: str = "Learning Curves",
    xlabel: str = "Training Sample Size (n)",
    ylabel: str = "Test Error",
    save_path: Optional[str] = None,
    colors: Optional[Dict[str, str]] = None,
    theoretical_bounds: Optional[Dict[str, callable]] = None,
    figsize: Tuple = (10, 6),
):
    """
    Plot learning curves for multiple learners.

    Args:
        results_dict: {learner_name: {sample_size: [errors]}}
        title: Plot title
        save_path: Path to save figure
        colors: Custom colors for each learner
        theoretical_bounds: {name: function(n) → bound}
    """
    fig, ax = plt.subplots(figsize=figsize)

    color_cycle = list(COLORS.values())
    if colors is None:
        colors = {}

    for i, (name, results) in enumerate(results_dict.items()):
        color = colors.get(name, color_cycle[i % len(color_cycle)])
        sample_sizes = sorted(results.keys())
        means = [np.mean(results[n]) for n in sample_sizes]
        stds = [np.std(results[n]) for n in sample_sizes]

        ax.plot(sample_sizes, means, "o-", color=color, label=name,
                linewidth=2.0, markersize=5, zorder=5)
        ax.fill_between(
            sample_sizes,
            [m - s for m, s in zip(means, stds)],
            [m + s for m, s in zip(means, stds)],
            alpha=0.15, color=color,
        )

    # Plot theoretical bounds if provided
    if theoretical_bounds:
        for name, bound_fn in theoretical_bounds.items():
            sample_sizes = sorted(list(results_dict.values())[0].keys())
            bounds = [bound_fn(n) for n in sample_sizes]
            ax.plot(sample_sizes, bounds, "--", color="gray", alpha=0.6,
                    label=f"{name} (theory)", linewidth=1.5)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight="bold", pad=15)
    ax.legend(loc="upper right", framealpha=0.9)
    ax.set_ylim(bottom=-0.02, top=max(1.0, ax.get_ylim()[1]))

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  → Saved: {save_path}")
    plt.close()


def plot_erm_failure_analysis(
    erm_results: Dict[int, List[float]],
    star_results: Dict[int, List[float]],
    k: int,
    save_path: Optional[str] = None,
):
    """
    Create a detailed analysis plot of ERM failure vs correct learner.
    Shows both the error curves and annotates the key thresholds.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))

    sample_sizes = sorted(erm_results.keys())

    # Left panel: Learning curves comparison
    erm_means = [np.mean(erm_results[n]) for n in sample_sizes]
    erm_stds = [np.std(erm_results[n]) for n in sample_sizes]
    star_means = [np.mean(star_results[n]) for n in sample_sizes]
    star_stds = [np.std(star_results[n]) for n in sample_sizes]

    ax1.plot(sample_sizes, erm_means, "o-", color=COLORS["red"],
             label="ERM Learner", linewidth=2, markersize=5)
    ax1.fill_between(sample_sizes,
                     [m - s for m, s in zip(erm_means, erm_stds)],
                     [m + s for m, s in zip(erm_means, erm_stds)],
                     alpha=0.15, color=COLORS["red"])

    ax1.plot(sample_sizes, star_means, "s-", color=COLORS["green"],
             label="Default-Star Learner", linewidth=2, markersize=5)
    ax1.fill_between(sample_sizes,
                     [m - s for m, s in zip(star_means, star_stds)],
                     [m + s for m, s in zip(star_means, star_stds)],
                     alpha=0.15, color=COLORS["green"])

    # Annotate k/2 threshold
    ax1.axvline(x=k/2, color=COLORS["accent"], linestyle=":", linewidth=1.5,
                label=f"|A|/2 = {k//2} (critical threshold)")

    ax1.set_xlabel("Training Sample Size (n)")
    ax1.set_ylabel("Test Error")
    ax1.set_title("ERM Failure vs. Correct Learner", fontweight="bold")
    ax1.legend(loc="upper right", framealpha=0.9)
    ax1.set_ylim(-0.02, max(max(erm_means) + 0.1, 0.6))

    # Right panel: Error distribution at key sample size
    mid_n = sample_sizes[len(sample_sizes) // 2]
    erm_errors_at_mid = erm_results[mid_n]
    star_errors_at_mid = star_results[mid_n]

    bins = np.linspace(0, 1, 21)
    ax2.hist(erm_errors_at_mid, bins=bins, alpha=0.6, color=COLORS["red"],
             label=f"ERM (n={mid_n})", edgecolor="white")
    ax2.hist(star_errors_at_mid, bins=bins, alpha=0.6, color=COLORS["green"],
             label=f"Default-Star (n={mid_n})", edgecolor="white")

    ax2.set_xlabel("Test Error")
    ax2.set_ylabel("Frequency")
    ax2.set_title(f"Error Distribution at n={mid_n}", fontweight="bold")
    ax2.legend(loc="upper right", framealpha=0.9)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  → Saved: {save_path}")
    plt.close()


def plot_local_reg_comparison(
    results_dict: Dict[str, Dict[int, List[float]]],
    star_results: Dict[int, List[float]],
    save_path: Optional[str] = None,
):
    """
    Compare different local regularization strategies against the correct learner.
    """
    fig, ax = plt.subplots(figsize=(11, 6))

    sample_sizes = sorted(star_results.keys())

    # Plot Default-Star as reference
    star_means = [np.mean(star_results[n]) for n in sample_sizes]
    ax.plot(sample_sizes, star_means, "s-", color=COLORS["green"],
            label="Default-Star (correct)", linewidth=2.5, markersize=6, zorder=10)

    # Plot each local regularizer
    style_cycle = ["o-", "^-", "D-", "v-", "p-"]
    color_list = [COLORS["red"], COLORS["accent"], COLORS["blue"],
                  COLORS["purple"], COLORS["teal"]]

    for i, (name, results) in enumerate(results_dict.items()):
        means = [np.mean(results[n]) for n in sample_sizes]
        stds = [np.std(results[n]) for n in sample_sizes]
        ax.plot(sample_sizes, means, style_cycle[i % len(style_cycle)],
                color=color_list[i % len(color_list)],
                label=f"Local Reg: {name}", linewidth=1.5, markersize=4, alpha=0.85)
        ax.fill_between(sample_sizes,
                        [m - s for m, s in zip(means, stds)],
                        [m + s for m, s in zip(means, stds)],
                        alpha=0.08, color=color_list[i % len(color_list)])

    ax.set_xlabel("Training Sample Size (n)")
    ax.set_ylabel("Test Error")
    ax.set_title("Local Regularization Strategies vs. Correct Learner", fontweight="bold", pad=15)
    ax.legend(loc="upper right", framealpha=0.9, ncol=2)
    ax.set_ylim(bottom=-0.02)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  → Saved: {save_path}")
    plt.close()


def plot_symmetry_analysis(
    domain_size: int,
    A: set,
    B: set,
    C: set,
    sample_points: np.ndarray,
    save_path: Optional[str] = None,
):
    """
    Visualize the set structure and sample coverage for H△,
    showing why symmetry makes it hard for local regularizers.
    """
    fig, ax = plt.subplots(figsize=(10, 4))

    # Create a 1D visualization of the domain
    domain = np.arange(min(domain_size, 60))
    A_sorted = sorted(A)[:30]
    B_sorted = sorted(B)[:30]
    C_sorted = sorted(C)[:30]

    # Color bars for each set
    bar_height = 0.3
    for i, x in enumerate(A_sorted):
        ax.barh(2, 0.8, left=i, height=bar_height, color=COLORS["accent"], alpha=0.6, edgecolor="none")
    ax.text(-2, 2, "A", fontsize=12, fontweight="bold", color=COLORS["accent"], va="center")

    for i, x in enumerate(B_sorted):
        ax.barh(1, 0.8, left=i, height=bar_height, color=COLORS["green"], alpha=0.6, edgecolor="none")
    ax.text(-2, 1, "B", fontsize=12, fontweight="bold", color=COLORS["green"], va="center")

    for i, x in enumerate(C_sorted):
        ax.barh(0, 0.8, left=i, height=bar_height, color=COLORS["blue"], alpha=0.6, edgecolor="none")
    ax.text(-2, 0, "C", fontsize=12, fontweight="bold", color=COLORS["blue"], va="center")

    # Mark sample points on A
    sample_set = set(sample_points.tolist())
    for i, x in enumerate(A_sorted):
        if x in sample_set:
            ax.plot(i + 0.4, 2.3, "v", color=COLORS["navy"], markersize=6)

    ax.set_title("Set Structure in H△ (sample points marked with ▼)", fontweight="bold")
    ax.set_xlabel("Elements (ordered)")
    ax.set_yticks([0, 1, 2])
    ax.set_yticklabels(["C", "B", "A"])
    ax.set_ylim(-0.5, 3.0)
    ax.grid(False)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  → Saved: {save_path}")
    plt.close()

