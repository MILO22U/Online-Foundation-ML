"""
learners.py

Implements three types of learners for the hypothesis class H△:

1. ERM Learner — selects any h ∈ H with zero empirical error
2. Default-Star Learner — the correct PAC learner from the paper
3. Local Regularization Learners — various ψ(h, x) strategies

The key insight: ERM fails because it can't distinguish the "true" set A
from a spurious set B that also achieves zero error. The Default-Star
learner succeeds by using a conservative strategy. Local regularizers
face the same fundamental problem as ERM due to the symmetry of H△.
"""

import numpy as np
from typing import List, Tuple, Optional, Callable
from .hypothesis_class import (
    Hypothesis,
    HypothesisClassHTriangle,
    STAR,
)


class ERMLearner:
    """
    Empirical Risk Minimizer for H△.

    Given sample S, selects any hypothesis h ∈ H with L_S(h) = 0.
    Breaks ties arbitrarily (random selection among zero-error hypotheses).

    This learner is shown to FAIL on H△ — it can predict the wrong set label
    for unseen test points.
    """

    def __init__(self, hypothesis_class: HypothesisClassHTriangle, seed: int = 42):
        self.H = hypothesis_class
        self.rng = np.random.default_rng(seed)

    def fit_predict(
        self, X_train: np.ndarray, Y_train: list, x_test: int
    ) -> object:
        """
        Train on sample (X_train, Y_train) and predict label for x_test.

        1. Find all h ∈ H with zero empirical error on training set
        2. Pick one uniformly at random
        3. Return h(x_test)
        """
        zero_error = self.H.find_zero_error_hypotheses(X_train, Y_train)

        if not zero_error:
            return STAR  # fallback

        chosen = zero_error[self.rng.integers(len(zero_error))]
        return chosen.predict(x_test)

    def evaluate(
        self,
        X_train: np.ndarray,
        Y_train: list,
        X_test: np.ndarray,
        Y_test: list,
    ) -> float:
        """Evaluate test error: fraction of test points predicted incorrectly."""
        errors = 0
        for x, y in zip(X_test, Y_test):
            pred = self.fit_predict(X_train, Y_train, int(x))
            if pred != y:
                errors += 1
        return errors / len(X_test) if len(X_test) > 0 else 0.0


class DefaultStarLearner:
    """
    The correct PAC learner for H△ from the paper.

    Algorithm:
      - Default: predict '*' at every x
      - If a label A ∋ x has been observed in the training sample, predict A
      - If two labels A, B both contain x and the sample reveals which is
        correct (via observations in A∩B), predict the correct one
      - If ambiguous, arbitrarily choose between A and B

    This learner succeeds because it only makes predictions based on
    observed evidence, avoiding the symmetry trap that catches ERM.
    """

    def __init__(self, seed: int = 42):
        self.rng = np.random.default_rng(seed)

    def fit_predict(
        self, X_train: np.ndarray, Y_train: list, x_test: int
    ) -> object:
        """
        Train on sample and predict label for x_test.

        Strategy:
        1. Collect all set-labels observed in training that contain x_test
        2. If none → predict '*'
        3. If exactly one set A ∋ x_test observed → predict A
        4. If two sets A, B both contain x_test → check if training data
           disambiguates (points in A∩B region) → predict accordingly
        """
        # Collect all distinct set-labels observed where x_test is a member
        observed_sets = []
        for x_tr, y_tr in zip(X_train, Y_train):
            if isinstance(y_tr, frozenset) and x_test in y_tr:
                if y_tr not in observed_sets:
                    observed_sets.append(y_tr)

        if len(observed_sets) == 0:
            return STAR

        if len(observed_sets) == 1:
            return observed_sets[0]

        # Multiple sets contain x_test — try to disambiguate
        # Check which set-label was actually observed at points in the
        # intersection region
        if len(observed_sets) == 2:
            A_set, B_set = observed_sets[0], observed_sets[1]
            intersection = A_set & B_set

            # Look for training points in the intersection
            for x_tr, y_tr in zip(X_train, Y_train):
                if int(x_tr) in intersection and isinstance(y_tr, frozenset):
                    # The label at a point in A∩B tells us which set is "on top"
                    return y_tr

        # If we can't disambiguate, pick randomly (still correct with some probability)
        return observed_sets[self.rng.integers(len(observed_sets))]

    def evaluate(
        self,
        X_train: np.ndarray,
        Y_train: list,
        X_test: np.ndarray,
        Y_test: list,
    ) -> float:
        """Evaluate test error."""
        errors = 0
        for x, y in zip(X_test, Y_test):
            pred = self.fit_predict(X_train, Y_train, int(x))
            if pred != y:
                errors += 1
        return errors / len(X_test) if len(X_test) > 0 else 0.0


class LocalRegularizationLearner:
    """
    Local regularization-based learner for H△.

    A local regularizer ψ(h, x) assigns a "complexity score" to each
    hypothesis h at each test point x. The learner selects among
    zero-error hypotheses the one minimizing ψ(h, x_test).

    We implement several strategies to explore whether any ψ can learn H△.
    """

    def __init__(
        self,
        hypothesis_class: HypothesisClassHTriangle,
        strategy: str = "set_size",
        seed: int = 42,
    ):
        """
        Args:
            hypothesis_class: The H△ instance
            strategy: Regularization strategy. Options:
                - "set_size": Prefer hypotheses whose active set at x is smaller
                - "star_preference": Prefer hypotheses that predict '*'
                - "coverage": Prefer hypotheses whose active set covers more of the domain
                - "min_intersection": Prefer hypotheses with smaller intersection regions
                - "random": Random regularizer (baseline)
        """
        self.H = hypothesis_class
        self.strategy = strategy
        self.rng = np.random.default_rng(seed)

    def psi(self, h: Hypothesis, x: int) -> float:
        """
        Local regularizer ψ(h, x).

        This is the core function — it assigns a complexity score to hypothesis h
        at test point x. Lower scores are preferred.

        IMPORTANT: ψ depends only on h and x, NOT on the training sample S.
        This is the key limitation that makes the open problem challenging.
        """
        label = h.predict(x)

        if self.strategy == "set_size":
            # Prefer hypotheses that predict smaller sets (or '*')
            if label == STAR:
                return 0.0
            return float(len(label)) if isinstance(label, frozenset) else 0.0

        elif self.strategy == "star_preference":
            # Strongly prefer predicting '*'
            if label == STAR:
                return 0.0
            return 1.0

        elif self.strategy == "coverage":
            # Prefer hypotheses whose predicted set covers more of the domain
            # (idea: larger sets are more "general" and thus simpler)
            if label == STAR:
                return float(self.H.domain_size)  # high penalty for star
            return float(self.H.domain_size - len(label)) if isinstance(label, frozenset) else 0.0

        elif self.strategy == "min_intersection":
            # Prefer hypotheses where x is in a smaller intersection region
            if x not in h.union_ABC:
                return 0.0
            if x in h.A_inter_B:
                return float(len(h.A_inter_B))
            if x in h.A_inter_C:
                return float(len(h.A_inter_C))
            if x in h.B_inter_C:
                return float(len(h.B_inter_C))
            return 0.0

        elif self.strategy == "random":
            # Random regularizer — no meaningful inductive bias
            return self.rng.random()

        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")

    def fit_predict(
        self, X_train: np.ndarray, Y_train: list, x_test: int
    ) -> object:
        """
        Train and predict using local regularization.

        1. Find all h ∈ H with L_S(h) = 0
        2. Among those, select h minimizing ψ(h, x_test)
        3. Return h(x_test)
        """
        zero_error = self.H.find_zero_error_hypotheses(X_train, Y_train)

        if not zero_error:
            return STAR

        # Evaluate regularizer for each zero-error hypothesis at x_test
        scores = [(h, self.psi(h, x_test)) for h in zero_error]
        min_score = min(s for _, s in scores)
        best = [h for h, s in scores if s == min_score]

        chosen = best[self.rng.integers(len(best))]
        return chosen.predict(x_test)

    def evaluate(
        self,
        X_train: np.ndarray,
        Y_train: list,
        X_test: np.ndarray,
        Y_test: list,
    ) -> float:
        """Evaluate test error."""
        errors = 0
        for x, y in zip(X_test, Y_test):
            pred = self.fit_predict(X_train, Y_train, int(x))
            if pred != y:
                errors += 1
        return errors / len(X_test) if len(X_test) > 0 else 0.0
