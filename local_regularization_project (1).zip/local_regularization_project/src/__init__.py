# Local Regularization for Multiclass Learning
# Implementation of Asilis et al. (COLT 2024)
