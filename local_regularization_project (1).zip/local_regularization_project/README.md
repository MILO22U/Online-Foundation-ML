# Can Local Regularization Learn All Multiclass Problems?

A Python implementation and experimental study of the open problem posed by Asilis et al. (COLT 2024).

## Overview

This project implements the key constructs from the paper:

1. **The Hypothesis Class H△** — A learnable multiclass hypothesis class built from triples of overlapping sets
2. **Learners:**
   - **ERM (Empirical Risk Minimizer)** — selects any zero-error hypothesis; shown to fail on H△
   - **Default-Star Learner** — the correct learner that defaults to `*` and uses observed labels
   - **Local Regularizer** — a ψ(h, x)-based learner; the open question is whether any such learner can learn H△
3. **Experiments** that reproduce the paper's theoretical arguments empirically

## Project Structure

```
local_regularization_project/
├── README.md
├── requirements.txt
├── run_experiments.py          # Main entry point — runs all experiments
├── src/
│   ├── __init__.py
│   ├── hypothesis_class.py     # H△ construction and hypothesis generation
│   ├── learners.py             # ERM, Default-Star, and Local Regularization learners
│   ├── pac_framework.py        # PAC learning evaluation framework
│   └── visualization.py        # Plotting utilities
└── results/                    # Output plots saved here
```

## Installation

```bash
pip install numpy matplotlib
```

## Usage

```bash
python run_experiments.py
```

This will run three experiments and save plots to `results/`:

1. **ERM Failure on H△** — Shows ERM incurs constant error even as sample size grows
2. **Default-Star Learner Success** — Shows the correct learner's error decreases with sample size
3. **Local Regularizer Analysis** — Tests various local regularization strategies and their limitations

## Key Concepts

### The Hypothesis Class H△

- **Domain:** X = {0, 1, 2, ..., N-1} (finite approximation of ℕ)
- **Labels:** Y = {*} ∪ {subsets of X}
- **Construction:** For each triple (A, B, C) of equal-size sets with pairwise intersections of size k/2 and empty triple intersection, we define 8 hypotheses — one for each way to "layer" the three sets on their pairwise overlaps.

### Why ERM Fails

On the uniform distribution over {(x, A) : x ∈ A}, an ERM learner with fewer than |A|/2 samples will, with constant probability, encounter an unseen test point. At that point, a zero-error hypothesis exists that predicts the wrong label — and ERM may choose it.

### The Open Problem

Can *any* local regularizer ψ(h, x) learn H△? The paper conjectures the answer is no, due to the symmetry of the class preventing sample-independent methods from distinguishing the "correct" label.

## References

- Asilis, Devic, Dughmi, Sharan, Teng. "Open Problem: Can Local Regularization Learn All Multiclass Problems?" COLT 2024.
- Brukhim et al. "A Characterization of Multiclass Learnability." FOCS 2022.
- Daniely & Shalev-Shwartz. "Optimal Learners for Multiclass Problems." COLT 2014.
