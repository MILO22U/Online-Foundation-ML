"""
run_experiments.py

Main entry point for running all experiments on the hypothesis class H△.

Experiments:
1. ERM Failure — demonstrates that ERM incurs constant error on H△
2. Default-Star Success — shows the correct learner achieves diminishing error
3. Local Regularizer Analysis — tests multiple ψ(h, x) strategies

Usage:
    python run_experiments.py
"""

import numpy as np
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.hypothesis_class import (
    HypothesisClassHTriangle,
    Hypothesis,
    generate_valid_triple,
    generate_hypotheses_for_triple,
    create_realizable_distribution,
    sample_from_distribution,
    STAR,
)
from src.learners import ERMLearner, DefaultStarLearner, LocalRegularizationLearner
from src.pac_framework import run_experiment, setup_erm_failure_experiment
from src.visualization import (
    plot_learning_curves,
    plot_erm_failure_analysis,
    plot_local_reg_comparison,
    plot_symmetry_analysis,
)


def experiment_1_erm_failure():
    """
    Experiment 1: Demonstrate ERM failure on H△.

    Setup:
    - Fix a triple (A, B, C) with |A| = |B| = |C| = k
    - Distribution D = uniform over {(x, A) : x ∈ A}
    - True hypothesis: h*(x) = A for x ∈ A, else *
    - Train ERM on samples of increasing size
    - Measure test error

    Expected result: ERM has constant error even as n grows (up to n ≈ k/2),
    while the Default-Star learner's error diminishes quickly.
    """
    print("=" * 65)
    print("EXPERIMENT 1: ERM Failure on H△")
    print("=" * 65)

    DOMAIN_SIZE = 500
    K = 60
    NUM_TRIPLES = 100
    SEED = 42

    # Build H△
    H_tri, dist, true_h = setup_erm_failure_experiment(
        domain_size=DOMAIN_SIZE, k=K, num_triples=NUM_TRIPLES, seed=SEED
    )

    sample_sizes = [2, 5, 10, 15, 20, 25, 30, 40, 50, 60]

    # --- ERM Learner ---
    print("\n[ERM Learner]")
    erm = ERMLearner(H_tri, seed=SEED)
    erm_results = run_experiment(erm, dist, sample_sizes, n_test=40, n_trials=20, seed=SEED)

    # --- Default-Star Learner ---
    print("\n[Default-Star Learner]")
    star = DefaultStarLearner(seed=SEED)
    star_results = run_experiment(star, dist, sample_sizes, n_test=40, n_trials=20, seed=SEED + 1)

    # --- Plot ---
    print("\nGenerating plots...")
    plot_erm_failure_analysis(
        erm_results, star_results, k=K,
        save_path="results/exp1_erm_failure.png"
    )

    plot_learning_curves(
        {"ERM Learner": erm_results, "Default-Star Learner": star_results},
        title=f"ERM Failure on H△  (k={K}, domain={DOMAIN_SIZE})",
        save_path="results/exp1_learning_curves.png",
        colors={"ERM Learner": "#C0392B", "Default-Star Learner": "#2D8A56"},
    )

    return erm_results, star_results


def experiment_2_correct_learner_scaling():
    """
    Experiment 2: Show the Default-Star learner scales well.

    Tests the correct learner across different problem sizes (k values)
    to verify that sample complexity scales appropriately.
    """
    print("\n" + "=" * 65)
    print("EXPERIMENT 2: Default-Star Learner Scaling")
    print("=" * 65)

    DOMAIN_SIZE = 300
    SEED = 123

    k_values = [10, 20, 40]
    all_results = {}

    for k in k_values:
        print(f"\n--- k = {k} ---")
        rng = np.random.default_rng(SEED)
        H_tri = HypothesisClassHTriangle(
            domain_size=DOMAIN_SIZE, k=k, num_triples=40, seed=SEED
        )
        A, B, C = H_tri.triples[0]
        true_h = Hypothesis(A, B, C, ab_label="A", ac_label="A", bc_label="B")
        dist = create_realizable_distribution(A, true_h)

        star = DefaultStarLearner(seed=SEED)
        max_n = min(k * 3, 60)
        sample_sizes = list(range(2, max_n + 1, max(1, max_n // 8)))

        results = run_experiment(star, dist, sample_sizes, n_test=40, n_trials=15, seed=SEED)
        all_results[f"k={k}"] = results

    # Plot
    print("\nGenerating plot...")
    plot_learning_curves(
        all_results,
        title="Default-Star Learner: Scaling with Problem Size (k)",
        save_path="results/exp2_scaling.png",
        colors={f"k={k}": c for k, c in zip([10, 20, 40], ["#2D8A56", "#1A7A6D", "#2B3A67"])},
    )

    return all_results


def experiment_3_local_regularizer_comparison():
    """
    Experiment 3: Compare local regularization strategies.

    Tests multiple ψ(h, x) strategies to see if any can match the
    Default-Star learner's performance. The conjecture is that none
    can, due to the symmetry of H△.
    """
    print("\n" + "=" * 65)
    print("EXPERIMENT 3: Local Regularization Strategy Comparison")
    print("=" * 65)

    DOMAIN_SIZE = 500
    K = 60
    NUM_TRIPLES = 100
    SEED = 42

    H_tri, dist, true_h = setup_erm_failure_experiment(
        domain_size=DOMAIN_SIZE, k=K, num_triples=NUM_TRIPLES, seed=SEED
    )

    sample_sizes = [2, 5, 10, 15, 20, 25, 30, 40, 50, 60]

    strategies = ["set_size", "star_preference", "coverage", "min_intersection", "random"]
    local_reg_results = {}

    for strategy in strategies:
        print(f"\n[Local Regularizer: {strategy}]")
        lr = LocalRegularizationLearner(H_tri, strategy=strategy, seed=SEED)
        results = run_experiment(lr, dist, sample_sizes, n_test=40, n_trials=15, seed=SEED)
        local_reg_results[strategy] = results

    # Also run Default-Star for comparison
    print("\n[Default-Star Learner (reference)]")
    star = DefaultStarLearner(seed=SEED)
    star_results = run_experiment(star, dist, sample_sizes, n_test=40, n_trials=15, seed=SEED + 1)

    # Plot
    print("\nGenerating plot...")
    plot_local_reg_comparison(
        local_reg_results, star_results,
        save_path="results/exp3_local_reg_comparison.png"
    )

    # Also plot the set structure
    A, B, C = H_tri.triples[0]
    rng = np.random.default_rng(SEED)
    sample_X, _ = sample_from_distribution(dist, n=8, rng=rng)
    plot_symmetry_analysis(
        DOMAIN_SIZE, A, B, C, sample_X,
        save_path="results/exp3_symmetry.png"
    )

    return local_reg_results, star_results


def print_summary(erm_results, star_results, local_reg_results):
    """Print a concise summary of all experimental findings."""
    print("\n" + "=" * 65)
    print("SUMMARY OF RESULTS")
    print("=" * 65)

    # Get the largest sample size tested
    max_n = max(erm_results.keys())

    print(f"\nAt largest sample size n={max_n}:")
    print(f"  ERM Learner:          mean error = {np.mean(erm_results[max_n]):.4f}")
    print(f"  Default-Star Learner: mean error = {np.mean(star_results[max_n]):.4f}")

    max_n_lr = max(list(local_reg_results.values())[0].keys())
    print(f"\nLocal Regularizer results at n={max_n_lr}:")
    for strategy, results in local_reg_results.items():
        print(f"  ψ = {strategy:20s}: mean error = {np.mean(results[max_n_lr]):.4f}")

    print("\nKey findings:")
    print("  ✗ ERM maintains high error — cannot distinguish true label from spurious ones")
    print("  ✓ Default-Star achieves low error — conservative strategy avoids the trap")
    print("  ? Local regularizers struggle — symmetry prevents sample-independent learning")
    print()
    print("This supports the conjecture that H△ may NOT be learnable by any local regularizer.")
    print("The open problem remains: can we prove this formally?")


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)

    print("╔══════════════════════════════════════════════════════════════════╗")
    print("║  Can Local Regularization Learn All Multiclass Problems?        ║")
    print("║  Experimental Study — Asilis et al. (COLT 2024)                ║")
    print("╚══════════════════════════════════════════════════════════════════╝\n")

    # Run all experiments
    erm_results, star_results_1 = experiment_1_erm_failure()
    scaling_results = experiment_2_correct_learner_scaling()
    local_reg_results, star_results_3 = experiment_3_local_regularizer_comparison()

    # Summary
    print_summary(erm_results, star_results_1, local_reg_results)

    print("\nAll results saved to results/ directory.")
    print("Done!")
